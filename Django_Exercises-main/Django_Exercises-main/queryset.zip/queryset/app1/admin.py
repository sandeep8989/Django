from django.contrib import admin
from app1.models import student,employee
# Register your models here.
@admin.register(student)
class student_admin(admin.ModelAdmin):
    list_display = ['name','sno','mob','email','city']

@admin.register(employee)
class employee_admin(admin.ModelAdmin):
    list_display = ['emp_name','emp_id','date']