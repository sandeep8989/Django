from django.shortcuts import render
import datetime
# Create your views here.
def fun2(request):
    x = datetime.datetime.now()
    return render(request,'index1.html',{'date':x})


def fun3(request):
    return render(request,'index3.html')