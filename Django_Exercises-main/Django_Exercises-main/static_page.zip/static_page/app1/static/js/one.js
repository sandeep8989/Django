function myFunction() {
  alert("I am an alert box!");
}
alert("The file is working")