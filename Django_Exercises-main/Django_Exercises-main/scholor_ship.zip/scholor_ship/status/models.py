from django.db import models

# Create your models here.


class scholor_model(models.Model):
    scholor_name = models.CharField(max_length=20)
    scholoe_id = models.IntegerField(unique=True)
    education_choices = (
        ('10th','ssc'),
        ('Inter','Inter'),
        ('Degree','Degree'),

    )

    education = models.CharField(choices=education_choices,max_length=10,default=1)

    gender_choices = (
        ('male','Male'),
        ('female','female'),
    )
    gender = models.CharField(choices=gender_choices,max_length=10,default=1)
    Aadhar_no = models.IntegerField(unique=True)
    year = models.DateField()
    address = models.TextField()
