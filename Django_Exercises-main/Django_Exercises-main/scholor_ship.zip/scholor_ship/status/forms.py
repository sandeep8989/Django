from django .forms import ModelForm

from status . models import scholor_model

class scholor_form(ModelForm):
    class Meta:
        model = scholor_model
        fields = '__all__'