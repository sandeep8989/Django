from django.shortcuts import render
from status .models import scholor_model
from status.forms import scholor_form
from django.contrib import messages
# Create your views here.


def scholor(request):
    if request.method == 'POST':
        fm=scholor_form(request.POST)
        if fm.is_valid():
            scholor_name = fm.cleaned_data['scholor_name']
            scholoe_id = fm.cleaned_data['scholoe_id']
            education = fm.cleaned_data['education']
            gender = fm.cleaned_data['gender']
            Aadhar_no = fm.cleaned_data['Aadhar_no']
            year = fm.cleaned_data['year']
            address = fm.cleaned_data['address']
            db = scholor_model(scholor_name=scholor_name,scholoe_id=scholoe_id,education=education,gender=gender,Aadhar_no=Aadhar_no,year=year,address=address)
            db.save()


    else:
        fm = scholor_form()
    return render(request,'scholor.html',{'form':fm})