from django.contrib import admin
from status . models import scholor_model
# Register your models here.
admin.site.register(scholor_model)