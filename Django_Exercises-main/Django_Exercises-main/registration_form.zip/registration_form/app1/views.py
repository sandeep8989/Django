from django.shortcuts import render,HttpResponseRedirect
from app1.forms import Signup
from django.contrib import messages
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import authenticate,login,logout
# Create your views here.

def signup(request):
    if request.method=='POST':
        fm = Signup(request.POST)
        if fm.is_valid():
            messages.success(request,'account created sucssesfully')
            fm.save()
    else:
        fm = Signup()
    return render(request,'signup.html',{'form':fm})


def login_page(request):
    if not request.user.is_authenticated:
        if request.method == 'POST':
            fm = AuthenticationForm(request=request,data=request.POST)
            if fm.is_valid():
                username = fm.cleaned_data['username']
                password = fm.cleaned_data['password']
                db=authenticate(username=username,password=password)
                db.save()
                if db is not None:
                    login(request,db)
                    messages.success(request,'Updated Succssesfully')
                    return HttpResponseRedirect('/profile/')
        else:
            fm = AuthenticationForm()
            return render(request,'login.html',{'form':fm})
    else:
        return HttpResponseRedirect('/profile/')


def profile_page(request):
    if request.user.is_authenticated:
        return render(request, 'userprofile.html', {"name": request.user})
    else:
        return HttpResponseRedirect('/login/')

def logoutuser(request):
    logout(request)
    return HttpResponseRedirect('/login/')
