from django import forms
from django.forms import ModelForm
from hotel . models import Crud_model


class Curd_form(ModelForm):
    class Meta:
        model = Crud_model
        fields = '__all__'