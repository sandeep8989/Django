from django.contrib import admin
from .models import Crud_model
# Register your models here.
@admin.register(Crud_model)
class one(admin.ModelAdmin):
    list_display = ['RoomType','num_of_guests','Fullname','start_date','end_date','mob','email','message']
