
from django.shortcuts import render
from hotel.models import Crud_model
from hotel.forms import Curd_form
from django.http import HttpResponseRedirect
from django.contrib import messages


# Create your views here.
def Crud(request):
    if request.method == 'POST':
        fm = Curd_form(request.POST)
        if fm.is_valid():
            RoomType = fm.cleaned_data['RoomType']
            num_of_guests = fm.cleaned_data['num_of_guests']
            Fullname = fm.cleaned_data['Fullname']
            start_date = fm.cleaned_data['start_date']
            end_date = fm.cleaned_data['end_date']
            mob = fm.cleaned_data['mob']
            email = fm.cleaned_data['email']
            message = fm.cleaned_data['message']

            db = Crud_model(RoomType=RoomType,num_of_guests=num_of_guests,Fullname=Fullname,start_date=start_date,end_date=end_date,mob=mob,email=email,message=message)
            db.save()
            fm = Curd_form()
    else:
        fm = Curd_form()
    data = Crud_model.objects.all()
    return render(request,'index.html',{'form':fm,'fetch': data})

def update(request,id):
    if request.method == 'POST':
        pi = Crud_model.objects.get(pk=id)
        fm = Curd_form(request.POST,instance=pi)
        if fm.is_valid():
            fm.save()
            messages.info(request,'Data Updated Successfully')

    else:
        pi = Crud_model.objects.get(pk=id)
        fm = Curd_form(instance=pi)

    return render(request,'update.html',{'form':fm})

def delete(request,id):
    if request.method == 'POST':
        fm = Crud_model.objects.get(pk=id)
        fm.delete()
        return HttpResponseRedirect('/')


