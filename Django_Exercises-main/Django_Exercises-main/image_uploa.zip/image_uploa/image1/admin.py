from django.contrib import admin
from image1 .models import image_model
# Register your models here.
admin.site.register(image_model)