from django.apps import AppConfig


class Image1Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'image1'
