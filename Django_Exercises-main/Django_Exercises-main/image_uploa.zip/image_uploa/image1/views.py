from django.shortcuts import render
from image1 .models import image_model
# Create your views here.
def image(request):
    md = image_model.objects.all()
    return render(request,'index.html',{'model':md})