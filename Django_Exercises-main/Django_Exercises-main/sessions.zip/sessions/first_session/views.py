from django.shortcuts import render

# Create your views here.
def set_session(request):
    request.session['name'] = 'krishna'
    request.session['dicts'] = {'name':'Bhargav','designation':'Iam a Python Developer'}
    request.session['lists'] = ['python','django','javascript']
    return render(request,'set.html')


def get_session(request):
    if 'name' in request.session:
        name = request.session['name']
        request.session.modified = True
        dicts = request.session['dicts']
        lists = request.session['lists']
        return render(request,'get.html',{'dicts':dicts,'lists':lists,'name':name})
    else:
        return render('Session has Expired')

def delete_session(request):
    request.session.flush()
    request.session.clear_expired()
    return render(request,'delete.html')